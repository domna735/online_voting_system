<footer>
    <p>&copy; 2025 Online Voting System. All rights reserved.
        <br>3117 Project group 17
        <br>University of Hong Kong Polyu
        <br>Group members: Ma Kai Lun Donovan, Wong Kin Hei Kevin, Lam Ka Hong
    </p>
</footer>